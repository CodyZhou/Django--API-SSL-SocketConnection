#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @File    : masterserver.py
# @Time    : 2017/3/16 11:02
# @Author  : Cody Zhou
# @Software: PyCharm
# @Description: 
#
#
from pythontest.libs.libserver import MasterServer

if __name__ == '__main__':
    ms = MasterServer()
    ms.run()

