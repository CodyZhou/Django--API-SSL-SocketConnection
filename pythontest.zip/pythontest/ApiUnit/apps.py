from django.apps import AppConfig


class ApiunitConfig(AppConfig):
    name = 'ApiUnit'
